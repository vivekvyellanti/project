from functools import total_ordering
import os
from re import search
import re
from flask import Flask, render_template, request, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from sqlalchemy.schema import UniqueConstraint


basedir = os.path.abspath(os.path.dirname(__file__))


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.path.join(basedir,'data.sqlite')
app.config['SQLALCHEMY_TRAC_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'DFDHJFSKLASKhjFGKLASDfjgh'
app.config['UPLOAD_FOLDER'] = basedir + '/static/images/'
#app.config['STATIC_FOLDER'] = basedir + '/static/'

db = SQLAlchemy(app)

class Orders(db.Model):

    __tablename__= "Orders"

    oid = db.Column(db.Integer, primary_key = True)
    fullname = db.Column(db.Text)
    email = db.Column(db.Text, nullable=False)
    address = db.Column(db.Text)
    city = db.Column(db.Text)
    state = db.Column(db.Text)
    zip = db.Column(db.Text)
    noc = db.Column(db.Text)
    ccn = db.Column(db.Integer)
    month = db.Column(db.Text)
    year = db.Column(db.Integer)
    cvv = db.Column(db.Integer)
    total = db.Column(db.Integer)
    plist = db.Column(db.Text)
    pqty = db.Column(db.Text)
    ostat = db.Column(db.Text)

    def __init__(self,fullname,email,address,city,state,zip,noc,ccn,month,year,cvv,total,plist,pqty,ostat):
        self.fullname = fullname
        self.email = email
        self.address = address
        self.city = city
        self.state = state
        self.zip = zip
        self.noc = noc
        self.ccn = ccn
        self.month = month
        self.year = year
        self.cvv = cvv
        self.total = total
        self.plist = plist
        self.pqty = pqty
        self.ostat = ostat




class Category(db.Model):
    __tablename__ = "Category"

    cid = db.Column(db.Integer, primary_key = True)
    cname = db.Column(db.Text)

    def __init__(self,cname):
        self.cname = cname

class Customer(db.Model):

    __tablename__ = "Customer"

    cid = db.Column(db.Integer, primary_key = True)
    email = db.Column(db.Text, nullable=False , unique=True)
    cfname = db.Column(db.Text)
    clname = db.Column(db.Text)
    cpassword = db.Column(db.Text)

    def __init__(self,email,cfname,clname,cpassword):
      self.email = email
      self.cfname = cfname
      self.clname = clname
      self.cpassword = cpassword 

class ecat(db.Model):

   __tablename__ = "ecat"

   eid = db.Column(db.Integer, primary_key = True)
   username = db.Column(db.Text, nullable=False , unique=True)
   efname  = db.Column(db.Text)
   elname = db.Column(db.Text)
   eemail = db.Column(db.Text)
   password = db.Column(db.Text , nullable=False)
   cat      = db.Column(db.Text)
   

   def __init__(self,username,efname,elname,eemail,password,cat):
      self.username = username
      self.efname = efname
      self.elname = elname
      self.eemail = eemail
      self.password = password
      self.cat = cat



class Products(db.Model):

    __tablename__ = "Products"

    pid = db.Column(db.Integer, primary_key = True)
    pname = db.Column(db.Text)
    pdis = db.Column(db.Text)
    price = db.Column(db.Integer)
    stock = db.Column(db.Integer)
    fname = db.Column(db.Text)
    pcat = db.Column(db.Text)
    retail = db.Column(db.Integer)
    
    
    def __init__(self,pname,pdis,price,stock,fname,pcat,retail):
        self.pname = pname
        self.pdis = pdis
        self.price = price
        self.stock = stock
        self.fname = fname
        self.pcat = pcat
        self.retail = retail


class Dealers(db.Model):

    __tablename__ = "Dealers"

    did = db.Column(db.Integer, primary_key = True)
    dname = db.Column(db.Text)
    dcontact = db.Column(db.Integer)
    address = db.Column(db.Text)


    def __init__(self,dname,dcontact,address):
        self.dname = dname
        self.dcontact = dcontact
        self.address = address

db.create_all()

ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

def listToString(s): 
    
    return ";".join(str(x) for x in s)

estatus = 0
cstatus = 0


cartlist = []
cqty = []

class catli:
    def __init__(self):
        self._catlist = []
        cat = Category.query.all()
        for i in range(len(cat)):
            self._catlist.append(cat[i].cname)
    def up(self,cate):
        self._catlist.append(cate)
    def cat(self):
        return self._catlist

cats = catli()

class session:
    
    def __init__(self):
        self._total = 0

    def up(self, total):
        self._total = total
    def tot(self):
        return self._total
class usession:

    def __init__(self):

        self._id = 0
        self._email = ""

    def up(self,id,email):
        self._id = id
        self._email = email
    def scid(self):
        return self._id
    def sce(self):
        return self._email

nus = usession()

usern = ""
 
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route ('/', methods=['GET','POST'])
def index():
    return render_template('login.html')

@app.route('/prodfilter', methods=['GET','POST'])
def prodfilter():
    cat = request.form['cat']
    search = request.form['search']
    if cat != "All" and search:
        pinf = Products.query.filter(Products.pcat==cat , Products.pname == search)
    
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())
    if search:
        pinf = Products.query.filter(Products.pname == search)
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())
    if cat !="All":
        print(cats.cat())
        pinf = Products.query.filter(Products.pcat==cat)
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())

@app.route('/prodfilterprice', methods=['GET','POST'])
def prodfilterprice():
    cat = request.form['min']
    search = request.form['max']

    if cat  and search:
        pinf = Products.query.filter(Products.price>= cat , Products.price <= search)
    
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())
    if search:
        pinf = Products.query.filter(Products.price <= search)
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())
    if cat:
        print(cats.cat())
        pinf = Products.query.filter(Products.price>=cat)
        image_names= os.listdir(app.config['UPLOAD_FOLDER'])
        return render_template('customer.html',prodList= pinf,image_names=image_names,catinf = cats.cat())


@app.route('/cpreferences1',methods = ["GET"])
def cpreferences1():
    return render_template("preferences.html")


@app.route('/cpref', methods = ['POST','GET'])
def cpref():
    print("************************************************************")
    print(nus.scid())
    print("************************************************************")
    pref = Customer.query.get(nus.scid())
    password = request.form["password"]
    npass = request.form["npass"]
    cpass = request.form["cpass"]

    if npass == cpass:
        if password == pref.cpassword:
            pref.cpassword = npass
            db.session.add(pref)
            db.session.commit()

            return render_template("preferences.html")




@app.route('/prods')
def prods():
    
    return show()

def show():
    #usern = email
    prodList = Products.query.all()
    image_names= os.listdir(app.config['UPLOAD_FOLDER'])
    print("************************************************************")
    print(nus.scid())
    print("************************************************************")
    return render_template('customer.html',prodList= prodList,image_names=image_names,catinf = cats.cat())
       

@app.route('/cart/<cpid>',methods=['GET','POST'])
def cart(cpid):
    qty = request.form["qty"]
    if qty == "" :
        cqty.append(1)
    else:
        cqty.append(qty)

    cartlist.append(cpid)
    
    return show()
nses = session()
@app.route('/order')
def order():
    
    
    carsize = len(cartlist)
    List = []
    fprice = []
    
    for i in range(carsize):
        temp = Products.query.get(cartlist[i])
        List.append(temp.pname)
        fp = int(temp.price) * int(cqty[i])
        fprice.append(fp)
        print(List,fprice)
        total = sum(fprice)
        nses.up(total)



    return render_template("order.html",size = carsize,List=List,fp = fprice, total = nses.tot())

@app.route ('/clogin', methods=['GET','POST'])
def clogin():
    return render_template('clogin.html')

@app.route('/cmain', methods=['GET','POST'])
def cmain():
    
    email = request.form['email']
    cpassword = request.form['password']
    userinf = Customer.query.filter(Customer.email==email)
    
     

    upw = userinf[0].cpassword
    uln = userinf[0].email
    uid = userinf[0].cid

    nus.up(uid,uln)
    print("************************************************************")
    print(nus.scid())
    print("************************************************************")

    if(upw == cpassword):
        return show()
        
    else:
        return render_template('clogin.html',message ="login failed invalid username or password")

@app.route('/ccustomer', methods=['GET','POST'])
def ccustomer():
    
    email = request.form['email']
    fname = request.form['fname']
    lname = request.form['lname']
    password = request.form['password']
    cpassword = request.form['cpassword']
    if(password == cpassword):

        customer = Customer(email = email ,cfname = fname ,clname = lname,cpassword=password)
        db.session.add(customer)
        db.session.commit()

        return render_template("clogin.html")


    
@app.route('/checkout', methods = ['GET','POST'])
def checkout():
    
    
    fullname = request.form['firstname']
    email = request.form['email']
    address = request.form['address']
    city = request.form['city']
    state = request.form['state']
    zip = request.form['zip']
    noc = request.form['cardname']
    ccn = request.form['cardnumber']
    month = request.form['expmonth']
    year = request.form['expyear']
    cvv = request.form['cvv']
    plist = listToString(cartlist)
    pqty = listToString(cqty)
    ostat = "pending"
    total = nses.tot()
    norder = Orders(fullname,email,address,city,state,zip,noc,ccn,month,year,cvv,total,plist,pqty,ostat)
    db.session.add(norder)
    db.session.commit()

    for i in range(len(cartlist)):
        rem = Products.query.get(int(cartlist[i]))
        rem.stock = rem.stock - int(cqty[i])
        db.session.add(rem)
        db.session.commit()



    return render_template("thankyou.html")

@app.route('/prodp', methods=['GET','POST'])
def prodp():
    #if estatus == 0 :
    #    return render_template('login.html',message ="you need to login to access the page")
    return render_template('portal.html',username=usern)

@app.route('/addd', methods=['POST','GET'])
def addd():

   dname = request.form['dname']
   dcontact = request.form['dcontact']
   address = request.form['address']
   dealers = Dealers(dname = dname,dcontact = dcontact,address = address)
   db.session.add(dealers)
   db.session.commit()
   return render_template('dealer.html',username="uploaded")

@app.route('/dealer', methods=['GET','POST'])
def dealer():
    return render_template('dealer.html',username=usern)

@app.route('/viewdeal', methods = ['GET','POST'])
def viewdeal():
    dealList = Dealers.query.all()
    return render_template('viewtable.html',dealList= dealList)

@app.route('/main',methods=['GET','POST'])
def main():
    username = request.form['username']
    password = request.form['password']

    userinf = ecat.query.filter(ecat.username==username)

    upw = userinf[0].password
    if(upw == password):
        usern = username
        estatus = 1
        return render_template('portal.html',username=username)
    else:
        return render_template('login.html',message ="login failed invalid username or password")

@app.route('/addp', methods=['POST','GET'])

def addp():
   
    pname = request.form['pname']
    pdis = request.form['pdis']
    price = request.form['price']
    stock = request.form['stock']
    cat = request.form['cat']
    retail = request.form['retail']
    pic = request.files['img']

    filename = secure_filename(pic.filename)
    products = Products(pname,pdis,price,stock,pic.filename,cat,retail)
    

   
    print(pic)
    pic.save(app.config['UPLOAD_FOLDER']+"{}".format(pic.filename))

    db.session.add(products)
    db.session.commit()

    return render_template('portal.html',username="uploaded")

@app.route('/viewprod/<filename>')
def send_image(filename):
    
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/viewprod', methods = ['GET','POST'])
def viewprod():
    prodList = Products.query.all()
    filename = Products.fname
    image_names= os.listdir(app.config['UPLOAD_FOLDER'])
    
    return render_template('viewtable.html',prodList= prodList,image_names=image_names)

@app.route('/updatepage/<upid>', methods=['POST','GET'])
def updatepage(upid):
    return render_template('update.html',username="uploaded",upid = upid)

@app.route('/upprod/<updateid>', methods=['POST','GET'])
def upprod(updateid):
    print(updateid)
    updateprod = Products.query.get(updateid)
    if request.form['upname']:
        updateprod.pname = request.form['upname']
    if request.form['updis']:
        updateprod.pdis = request.form['updis']
    if request.form['upprice']:
        updateprod.price = request.form['upprice']
    if request.form['upstock']:
        updateprod.stock = request.form['upstock']
    db.session.add(updateprod)
    db.session.commit()
    return render_template('viewtable.html',username="uploaded")


@app.route('/deleteprod/<delid>',methods=['POST','GET'])
def deleteprod(delid):
    id = delid
    delproduct = Products.query.get(id)
    db.session.delete(delproduct)
    db.session.commit()
    return render_template('viewtable.html',username="uploaded")

@app.route('/orderdel/<delid>',methods=['POST','GET'])
def orderdel(delid):
    id = delid
    delproduct = Orders.query.get(id)
    db.session.delete(delproduct)
    db.session.commit()
    return render_template('viewtable.html',username="uploaded")

@app.route('/cdetails')
def cdetails():
    prodList = Customer.query.all()

    return render_template('viewtable.html',clist= prodList)

@app.route('/vieworders')
def vieworders():
    orderlist = Orders.query.all()
    return render_template('viewtable.html',olist= orderlist)

@app.route('/orderupdate/<upid>', methods=['POST','GET'])
def orderupdate(upid):
    return render_template('update.html',oupid = upid)

@app.route('/uporder/<updateorder>', methods=['POST','GET'])
def uporder(updateorder):
    print(updateorder)
    updateprod = Orders.query.get(updateorder)
    if request.form['oupname']:
        print(request.form['oupname'])
        updateprod.ostat = request.form['oupname']
        db.session.add(updateprod)
        db.session.commit()

@app.route('/employee', methods=['POST','GET'])
def employee():

    return render_template('employes.html')

@app.route('/adde', methods=['POST','GET'])
def adde():
    username = request.form['username']
    efname = request.form['efname']
    elname = request.form['elname']
    eemail = request.form['eemail']
    print(eemail)
    password = request.form['password']
    cat = request.form['cat']

    new_employee = ecat(username,efname,elname,eemail,password,cat)

    db.session.add(new_employee)
    db.session.commit()

    return render_template('employes.html')

@app.route('/viewe')
def viewe():
    elist = ecat.query.all()
    print(elist[0].eemail)
    return render_template('viewtable.html',elist = elist)

if __name__=='__main__':
     app.run(debug=True)
        